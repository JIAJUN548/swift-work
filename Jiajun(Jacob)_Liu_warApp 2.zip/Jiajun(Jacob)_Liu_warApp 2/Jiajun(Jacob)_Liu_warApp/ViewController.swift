//
//  ViewController.swift
//  Jiajun(Jacob)_Liu_warApp
//
//  Created by Period Two on 2018-10-29.
//  Copyright © 2018 Period Two. All rights reserved.
//

import UIKit

var cardArray:[Int] = [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 25 , 26 , 27 , 28 , 29 , 30 , 31, 32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 , 40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 , 48 ,49 , 50 , 51 , 52]
// create an array to contain all elements
var shuffledArray:[Int] = []
// this will save shuffled elements
var upperLimit: UInt32 = 52
// this set the shuffle limit
var loopRandom:Int = 0
// this is the random number to shuffle all cards
var cardplayer:Int = 0
// this shows the real number of cards
var cardcpu:Int = 0
// this shows the real number of cards
var scoreOfplayer:Int = 0
// this shows the score of player
var scoreOfcpu:Int = 0
// this shows the score of cpu

//let playerWarNumOne:Int = 0
//let playerWarNumTwo:Int = 0
//let playerWarNumThree:Int = 0
//let cpuWarNumOne:Int = 0
//let cpuWarNumTwo:Int = 0
//let cpuWarNumThree:Int = 0

var playerWarScore:Int = 0
// this shows the added number of all war cards
var cpuWarScore:Int = 0
// this shows the added number of all war cards
var totalWarScorePlayer:Int = 0
// this shows the war score
var totalWarScoreCpu:Int = 0
// this shows the war score
var warNum:Int = 0
// this shows the real card number during war

class ViewController: UIViewController {
    
    
    
    @IBOutlet weak var resetButton: UIButton!
    // create an outlet of button
    @IBOutlet weak var playButton: UIButton!
    // create an outlet of button
    @IBOutlet weak var cpuScore: UILabel!
    // create a label to show cpu scores
    @IBOutlet weak var playerScore: UILabel!
    // create a label to show player scores
    @IBOutlet weak var cpuCard: UIImageView!
    // create an outlet to display cpu card
    @IBOutlet weak var playerCard: UIImageView!
    // create an outlet to display player card

    
    @IBOutlet weak var cpuWarCardThree: UIImageView!
    // create an outlet to display the first cpu war card
    @IBOutlet weak var cpuWarCardTwo: UIImageView!
    // create an outlet to display the second cpu war card
    @IBOutlet weak var cpuWarCardOne: UIImageView!
    // create an outlet to display the third cpu war card
    @IBOutlet weak var playerWarCardThree: UIImageView!
    // create an outlet to display the first player war card
    @IBOutlet weak var playerWarCardTwo: UIImageView!
    // create an outlet to display the second player war card
    @IBOutlet weak var playerWarCardOne: UIImageView!
    // create an outlet to display the third player war card

    
    
    func goLeft (view : UIView) {
        view.center.x += 200
    }
    func goRight (view : UIView) {
        view.center.x -= 200
    }
    func goUp (view : UIView) {
        view.center.y += 200
    }
    func goDown (view : UIView) {
        view.center.y -= 200
    }
    
    
    override func viewDidLoad() {
       
        
        super.viewDidLoad()
        for _ in 1...52 {
            loopRandom = Int((arc4random_uniform(upperLimit)))
            // let looprandom be a random number
            shuffledArray.append(cardArray[loopRandom])
            // append the elements of array into shuffledArray
            cardArray.remove(at: loopRandom)
            // remove the element of the previous value
            upperLimit -= 1
            // minus the limit every time
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }


    @IBAction func playButtonPressed(_ sender: Any) {
        
      
        
     
        if shuffledArray.count >= 2 && shuffledArray.count <= 52 {
            // the code excutes when you have at leat two card remain
        let playerCardNumber = shuffledArray.remove(at: 0)
            // remove the card of the top and distribute to player
        let cpuCardNumber = shuffledArray.remove(at: 0)
            // remove the card of the top and distribute to cpu

        
        switch playerCardNumber {
        case 1...4:
            cardplayer = 2
            // show the real number of 2 when the card number is from 1 to 4
        case 5...8:
            cardplayer = 3
            // show the real number of 3 when the card number is from 5 to 8
        case 9...12:
            cardplayer = 4
            // show the real number of 4 when the card number is from 9 to 12
        case 13...16:
            cardplayer = 5
            // show the real number of 5 when the card number is from 13 to 16
        case 17...20:
            cardplayer = 6
            // show the real number of 6 when the card number is from 17 to 20
        case 21...24:
            cardplayer = 7
            // show the real number of 7 when the card number is from 21 to 24
        case 25...28:
            cardplayer = 8
            // show the real number of 8 when the card number is from 25 to 28
        case 29...32:
            cardplayer = 9
            // show the real number of 9 when the card number is from 29 to 32
        case 33...36:
            cardplayer = 10
            // show the real number of 10 when the card number is from 33 to 36
        case 37...40:
            cardplayer = 11
            // show the real number of 11 when the card number is from 37 to 40
        case 41...44:
            cardplayer = 12
            // show the real number of 12 when the card number is from 41 to 44
        case 45...48:
            cardplayer = 13
            // show the real number of 13 when the card number is from 45 to 48
        default:
            cardplayer = 14
            // show the real number of 14 when the card number is from 49 to 52
        }
        
        switch cpuCardNumber {
        case 1...4:
            cardcpu = 2
            // show the real number of 2 when the card number is from 49 to 52

        case 5...8:
            cardcpu = 3
            // show the real number of 3 when the card number is from 49 to 52

        case 9...12:
            cardcpu = 4
            // show the real number of 4 when the card number is from 49 to 52

        case 13...16:
            cardcpu = 5
            // show the real number of 5 when the card number is from 49 to 52

        case 17...20:
            cardcpu = 6
            // show the real number of 6 when the card number is from 49 to 52

        case 21...24:
            cardcpu = 7
            // show the real number of 7 when the card number is from 49 to 52

        case 25...28:
            cardcpu = 8
            // show the real number of 8 when the card number is from 49 to 52

        case 29...32:
            cardcpu = 9
            // show the real number of 9 when the card number is from 49 to 52

        case 33...36:
            cardcpu = 10
            // show the real number of 10 when the card number is from 49 to 52

        case 37...40:
            cardcpu = 11
            // show the real number of 11 when the card number is from 49 to 52

        case 41...44:
            cardcpu = 12
            // show the real number of 12 when the card number is from 49 to 52

        case 45...48:
            cardcpu = 13
            // show the real number of 13 when the card number is from 49 to 52

        default:
            cardcpu = 14
            // show the real number of 14 when the card number is from 49 to 52

        }
        
            
            
       UIView.animate(withDuration: 0.5, animations: {self.goUp(view: self.playerCard)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goDown(view: self.playerCard)})}
     
        self.playerCard.image = UIImage(named: String(playerCardNumber))
                
            }
       UIView.animate(withDuration: 0.5, animations: {self.goUp(view: self.cpuCard)}) {(finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goDown(view: self.cpuCard)})}
    
        self.cpuCard.image = UIImage(named: String(cpuCardNumber))
            }
            
       
       // playerCard.image = UIImage(named: String(playerCardNumber))
            // display the card removed from the top of the array
       // cpuCard.image = UIImage(named: String(cpuCardNumber))
            // display the card removed from the top of the array
        }else {
            // if there is no element inside the array , disable the play button and enable the rest button
            playButton.isHidden = true
            resetButton.isHidden = false
            
        }
        
        
      
        
        
        
        func myCardFunc (playerCardNum: Int , cpuCardNum: Int) -> Int {
        
            return playerCardNum - cpuCardNum
            
        }
        // create a function to compare the numbers of player and cpu and catch the return value
        
        
   
        if shuffledArray.count >= 2 && shuffledArray.count <= 52 {
            // code get excuted when have at least two cards remain
            
            playButton.isHidden = false
            // enable play button
            resetButton.isHidden = true
            // disable rest button
            let compareNum = myCardFunc(playerCardNum: cardplayer, cpuCardNum: cardcpu)
            // catch the return value of the function
            if compareNum > 0 {
                // when return value is geater than 0 , excute the following code
                
                scoreOfplayer += 2
                // player score plus 2
                scoreOfcpu += 0
                // cpu score stays remain
                playerScore.text = String(scoreOfplayer)
                // display the score on the label
                cpuScore.text = String(scoreOfcpu)
                // display the score on the label
                playerWarCardOne.isHidden = true
                // disable player war UIimage one
                playerWarCardTwo.isHidden = true
                // disable player war UIimage two
                playerWarCardThree.isHidden = true
                // disable player war UIimage three
                cpuWarCardOne.isHidden = true
                // disable cpu war UIimage one
                cpuWarCardTwo.isHidden = true
                // disable cpu war UIimage two
                cpuWarCardThree.isHidden = true
                // disable cpu war UIimage three

                
            }else if compareNum < 0 {
                // when return value is less than 0 , excute the following code

                scoreOfplayer += 0
                // player score stays remain
                scoreOfcpu += 2
                // cpu score plus 2
                playerScore.text = String(scoreOfplayer)
                // display the score on the label
                cpuScore.text = String(scoreOfcpu)
                // disable the score on the label
                //cpuScore.text = String(scoreOfcpu)
                playerWarCardOne.isHidden = true
                // disable player war UIimage one
                playerWarCardTwo.isHidden = true
                // disable player war UIimage two
                playerWarCardThree.isHidden = true
                // disable player war UIimage three
                cpuWarCardOne.isHidden = true
                // disable cpu war UIimage one
                cpuWarCardTwo.isHidden = true
                // disable cpu war UIimage two
                cpuWarCardThree.isHidden = true
                // disable cpu war UIimage three

                
                
                
            }else {
                // when return value is equal to 0 , excute the following code

                
                playerWarCardOne.isHidden = false
                // enable player war UIimage one
                playerWarCardTwo.isHidden = false
                // enable player war UIimage two
                playerWarCardThree.isHidden = false
                // enable player war UIimage three
                cpuWarCardOne.isHidden = false
                // enable cpu war UIimage one
                cpuWarCardTwo.isHidden = false
                // enable cpu war UIimage two
                cpuWarCardThree.isHidden = false
                // enable cpu war UIimage three
                func warFunc (warCardNum:Int ) -> Int{
                    // create a function to show the real num of cards during war
                    switch warCardNum {
                    case 1...4:
                        warNum = 2
                    // show the real number of 2 when the card number is from 1 to 4

                    case 5...8:
                        warNum = 3
                    // show the real number of 3 when the card number is from 5 to 8
                    case 9...12:
                        warNum = 4
                    // show the real number of 4 when the card number is from 9 to 12
                    case 13...16:
                        warNum = 5
                    // show the real number of 5 when the card number is from 13 to 16
                    case 17...20:
                        warNum = 6
                    // show the real number of 6 when the card number is from 17 to 20
                    case 21...24:
                        warNum = 7
                    // show the real number of 7 when the card number is from 21 to 24
                    case 25...28:
                        warNum = 8
                    // show the real number of 8 when the card number is from 25 to 28
                    case 29...32:
                        warNum = 9
                    // show the real number of 9 when the card number is from 29 to 32
                    case 33...36:
                        warNum = 10
                    // show the real number of 10 when the card number is from 33 to 36
                    case 37...40:
                        warNum = 11
                    // show the real number of 11 when the card number is from 37 to 40
                    case 41...44:
                        warNum = 12
                    // show the real number of 12 when the card number is from 41 to 44
                    case 45...48:
                        warNum = 13
                    // show the real number of 13 when the card number is from 45 to 48
                    default:
                        warNum = 14
                    // show the real number of 14 when the card number is from 49 to 52
                    }
                    return warNum
                    // retrun the value of int
                    
                }
                if shuffledArray.count >= 6 {
                    // code get excuted when have 6 more card
                let warPlayerOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                
                UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.playerWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.playerWarCardOne)})}
                        
                self.playerWarCardOne.image = UIImage(named: String(warPlayerOne))
                        
                    }
                    // display the image removed from the top
                let warPlayerTwo = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                
                UIView.animate(withDuration: 0.4, animations: {self.goLeft(view: self.playerWarCardTwo)}) { (finished) in if finished {UIView.animate(withDuration: 0.4, animations: {self.goRight(view: self.playerWarCardTwo)})}
                        
                    self.playerWarCardTwo.image = UIImage(named: String(warPlayerTwo))
                        
                    }
                    // display the image removed from the top
                let warPlayerThree = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                UIView.animate(withDuration: 0.3, animations: {self.goLeft(view: self.playerWarCardThree)}) { (finished) in if finished {UIView.animate(withDuration: 0.3, animations: {self.goRight(view: self.playerWarCardThree)})}
                        
                        self.playerWarCardThree.image = UIImage(named: String(warPlayerThree))
                        
                    }
                
                    // display the image removed from the top
                let warCpuOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.cpuWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.cpuWarCardOne)})}
                        
                        self.cpuWarCardOne.image = UIImage(named: String(warCpuOne))
                        
                    }
               
                    // display the image removed from the top
                let warCpuTwo = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                UIView.animate(withDuration: 0.4, animations: {self.goLeft(view: self.cpuWarCardTwo)}) { (finished) in if finished {UIView.animate(withDuration: 0.4, animations: {self.goRight(view: self.cpuWarCardTwo)})}
                        
                        self.cpuWarCardTwo.image = UIImage(named: String(warCpuTwo))
                        
                    }
                
                    // display the image removed from the top
                let warCpuThree = shuffledArray.remove(at: 0)
                UIView.animate(withDuration: 0.3, animations: {self.goLeft(view: self.cpuWarCardThree)}) { (finished) in if finished {UIView.animate(withDuration: 0.3, animations: {self.goRight(view: self.cpuWarCardThree)})}
                        
                        self.cpuWarCardThree.image = UIImage(named: String(warCpuThree))
                        
                    }
                    //remove the card from the top and assign its value to a constant
                
                    // display the image removed from the top
                let numOfPlayerWarOne = warFunc(warCardNum: warPlayerOne)
                    // catch the return value and assign it to a constant
                let numOfPlayerWarTwo = warFunc(warCardNum: warPlayerTwo)
                    // catch the return value and assign it to a constant
                let numOfPlayerWarThree = warFunc(warCardNum: warPlayerThree)
                    // catch the return value and assign it to a constant
                let numOfCpuWarOne = warFunc(warCardNum: warCpuOne)
                    // catch the return value and assign it to a constant
                let numOfCpuWarTwo = warFunc(warCardNum: warCpuTwo)
                    // catch the return value and assign it to a constant
                let numOfCpuWarThree = warFunc(warCardNum: warCpuThree)
                    // catch the return value and assign it to a constant
                
                totalWarScorePlayer = numOfPlayerWarOne + numOfPlayerWarTwo + numOfPlayerWarThree
                    // calculate all the card value in war
                totalWarScoreCpu = numOfCpuWarOne + numOfCpuWarTwo + numOfCpuWarThree
                    // calculate all the card value in war
                } else if shuffledArray.count == 4 {
                    // code get excuted when have 4 cards remained
                    let warPlayerOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.playerWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.playerWarCardOne)})}
                        
                        self.playerWarCardOne.image = UIImage(named: String(warPlayerOne))
                        
                    }
                    // display the image removed from the top
                    let warPlayerTwo = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.4, animations: {self.goLeft(view: self.playerWarCardTwo)}) { (finished) in if finished {UIView.animate(withDuration: 0.4, animations: {self.goRight(view: self.playerWarCardTwo)})}
                        
                        self.playerWarCardTwo.image = UIImage(named: String(warPlayerTwo))
                        
                    }
                    // display the image removed from the top
                    
                    let warCpuOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.cpuWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.cpuWarCardOne)})}
                        
                        self.cpuWarCardOne.image = UIImage(named: String(warCpuOne))
                        
                    }
                    // display the image removed from the top
                    let warCpuTwo = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.4, animations: {self.goLeft(view: self.cpuWarCardTwo)}) { (finished) in if finished {UIView.animate(withDuration: 0.4, animations: {self.goRight(view: self.cpuWarCardTwo)})}
                        
                        self.cpuWarCardTwo.image = UIImage(named: String(warCpuTwo))
                        
                    }
                    
                    // display the image removed from the top
                    
                    let numOfPlayerWarOne = warFunc(warCardNum: warPlayerOne)
                    // catch the return value and assign it to a constant
                    let numOfPlayerWarTwo = warFunc(warCardNum: warPlayerTwo)
                    // catch the return value and assign it to a constant
                    
                    let numOfCpuWarOne = warFunc(warCardNum: warCpuOne)
                    // catch the return value and assign it to a constant
                    let numOfCpuWarTwo = warFunc(warCardNum: warCpuTwo)
                    // catch the return value and assign it to a constant
                   
                    totalWarScorePlayer = numOfPlayerWarOne + numOfPlayerWarTwo
                    // calculate all the card value in war
                    totalWarScoreCpu = numOfCpuWarOne + numOfCpuWarTwo
                    // calculate all the card value in war
                }else if shuffledArray.count == 2 {
                    // code get excuted when there are only 2 cards
                    
                    let warPlayerOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.playerWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.playerWarCardOne)})}
                        
                        self.playerWarCardOne.image = UIImage(named: String(warPlayerOne))
                        
                    }
                    // display the image removed from the top
                   
                    let warCpuOne = shuffledArray.remove(at: 0)
                    //remove the card from the top and assign its value to a constant
                    UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.cpuWarCardOne)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.cpuWarCardOne)})}
                        
                        self.cpuWarCardOne.image = UIImage(named: String(warCpuOne))
                        
                    }
                    
                    // display the image removed from the top
                   
                    let numOfPlayerWarOne = warFunc(warCardNum: warPlayerOne)
                    // catch the return value and assign it to a constant
                   
                    let numOfCpuWarOne = warFunc(warCardNum: warCpuOne)
                    // catch the return value and assign it to a constant
                    totalWarScorePlayer = numOfPlayerWarOne
                    // calculate all the card value in war
                    totalWarScoreCpu = numOfCpuWarOne
                    // calculate all the card value in war
                }
            
                if totalWarScoreCpu > totalWarScorePlayer {
                    // code get excuted when player war score is lee than cpu's
                    scoreOfplayer += 0
                    // player score stays same
                    scoreOfplayer += 2
                    // add 2 score to cpu's
                    playerScore.text = String(scoreOfplayer)
                    // show the score of player
                    cpuScore.text = String(scoreOfcpu)
                    // show the score of cpu
                }else if totalWarScorePlayer > totalWarScoreCpu {
                    // code get excuted when player war greater is lee than cpu's
                    scoreOfcpu += 0
                    // cpu score stays same
                    scoreOfplayer += 2
                    // player score added 2
                    playerScore.text = String(scoreOfplayer)
                    // show the score of player
                    cpuScore.text = String(scoreOfcpu)
                    // show the score of cpu
                }
                
                
                
                
            }
   
           
          
        } else {
            
            playButton.isHidden = true
            // disable the play button
            resetButton.isHidden = false
            // enable rest button
            
        }
        
        
}
    

    @IBAction func restButtonPressed(_ sender: Any) {
        let myAlert = UIAlertController(title: "Game over!", message: "Your score is \(scoreOfplayer) , and CPU score is \(scoreOfcpu)", preferredStyle: .alert)
        myAlert.addAction(UIAlertAction(title: "Got it !", style: .default, handler: nil))
        present(myAlert , animated: true)
 
        cardArray += [1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 , 24 , 25 , 26 , 27 , 28 , 29 , 30 , 31, 32 , 33 , 34 , 35 , 36 , 37 , 38 , 39 , 40 , 41 , 42 , 43 , 44 , 45 , 46 , 47 , 48 ,49 , 50 , 51 , 52]
  
        // append all value back to card array
        playButton.isHidden = false
        // enable player button
        resetButton.isHidden = true
        // disable rest button
        playerWarCardOne.isHidden = true
        // disable war card
        playerWarCardTwo.isHidden = true
        // disable war card
        playerWarCardThree.isHidden = true
        // disable war card
        cpuWarCardOne.isHidden = true
        // disable war card
        cpuWarCardTwo.isHidden = true
        // disable war card
        cpuWarCardThree.isHidden = true
        // disable war card
        upperLimit = 52
        // change upper limit back to 52
        for _ in 1...52 {
            loopRandom = Int((arc4random_uniform(upperLimit)))
            // let looprandom be a random number
            shuffledArray.append(cardArray[loopRandom])
            // append the elements of array into shuffledArray
            cardArray.remove(at: loopRandom)
            // remove the element of the previous value
            upperLimit -= 1
            // minus the limit every time
        }
        scoreOfcpu = 0
        // rest the score of cpu
        cpuScore.text = String(scoreOfcpu)
        // show cpu score
        scoreOfplayer = 0
        // rest player score
        playerScore.text = String(scoreOfplayer)
        // show player score
        
        UIView.animate(withDuration: 0.1, animations: {self.goLeft(view: self.playerCard)}) {
            (finished) in if finished {
                UIView.animate(withDuration: 0.1, animations: {self.goRight(view: self.playerCard)})
                self.playerCard.image = UIImage(named: "gray_back")
            }
        }
        UIView.animate(withDuration: 0.5, animations: {self.goLeft(view: self.cpuCard)}) { (finished) in if finished {UIView.animate(withDuration: 0.5, animations: {self.goRight(view: self.cpuCard)})}
            
            self.cpuCard.image = UIImage(named: "gray_back")
            
        }
        
        // change card background back to gray card
        
        // change card background back to gray card
        
        
        
        
    }
    
    
   
}


