

import UIKit


class ViewController: UIViewController {


    @IBOutlet weak var totalScore: UILabel!
    // create a outlet
    @IBOutlet weak var diceTwoNumber: UILabel!
    // create a outlet
    @IBOutlet weak var diceOneNumber: UILabel!
    // create a outlet
    @IBOutlet weak var roundNumber: UILabel!
    // create a outlet
    @IBOutlet weak var blackDice: UIImageView!
    // create a outlet
    @IBOutlet weak var whiteDice: UIImageView!
    // create a outlet
    var diceScore:Int = 0
    //create a variable
    var secondDiceScore = 0
      //create a variable
    var totalDiceScore = 0
      //create a variable
    var myRoundNumber = 0
      //create a variable
    let zeroValue = 0
      //create a variable
   
    
    @IBOutlet weak var playButton: UIButton!
    // create a outlet
    
    @IBOutlet weak var restButton: UIButton!
    // create a outlet
    let alert = UIAlertController(title: "YOU FINISH THE GAME", message: " Conguation ", preferredStyle: .alert)
    // create an alert boxto show "YOU FINISH THE GAME" and send message " Conguation "
    override func viewDidLoad() {
        whiteDice.image = #imageLiteral(resourceName: "images-1.png")
        // set the image of the image view
        blackDice.image = #imageLiteral(resourceName: "images.png")
         // set the image of the image view
        super.viewDidLoad()
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        // set one button for alert box called OK
     
       
    
    }
   
    
    

    

    @IBAction func rollDice(_ sender: Any) {
        
      
        
        
        func countScoreOne () {
            
            let myWhiteDice = Int.random(in: 1...6)
            // create a random number
            let myBlackDice = Int.random(in: 1...6)
            // create a random number
            

           
           
            whiteDice.image = UIImage(named: "topDice")
            //let the image of imageviewe be a UIimage
            blackDice.image = UIImage(named: "buttomDice")
             //let the image of imageviewe be a UIimage
          
            
            
            switch myWhiteDice {
            case 1:
                whiteDice.image = #imageLiteral(resourceName: "dice_1-128.png")
                // when random number equals 1 show the dice image 1
                
                
            case 2:
                whiteDice.image = #imageLiteral(resourceName: "dice_2-128.png")
                // when random number equals 2 show the dice image 2
                
             

            case 3:
                whiteDice.image = #imageLiteral(resourceName: "dice_3-512.png")
                // when random number equals 3 show the dice image 3
            
            case 4:
                whiteDice.image = #imageLiteral(resourceName: "dice_4-128.png")
                // when random number equals 4 show the dice image 4
                
             

            case 5:
                whiteDice.image = #imageLiteral(resourceName: "dice_5-128.png")
                // when random number equals 5 show the dice image 5
               
                
            default:
                whiteDice.image = #imageLiteral(resourceName: "dice_6-128.png")
                // when random number equals 6 show the dice image 6
              
            
            }
            
            
            if myBlackDice == 1 {
                
                blackDice.image = #imageLiteral(resourceName: "dice_black_1-128.png")
                // when random number equals 1 show the dice image 1
            

                
                
            }else if myBlackDice == 2 {
                blackDice.image = #imageLiteral(resourceName: "dice_black_2-128.png")
                // when random number equals 2 show the dice image 2
             

            }else if myBlackDice == 3{
                blackDice.image = #imageLiteral(resourceName: "dice_black_3-128.png")
                
                // when random number equals 3 show the dice image 3

                
            }else if myBlackDice == 4{
                
                blackDice.image = #imageLiteral(resourceName: "dice_black_4-128.png")
             // when random number equals 4 show the dice image 4
                
            }else if myBlackDice == 5 {
               
                blackDice.image = #imageLiteral(resourceName: "dice_black_5-128.png")
                // when random number equals 5 show the dice image 5
                
            }else {
                blackDice.image = #imageLiteral(resourceName: "dice_black_6-128.png")
               // when random number equals 6 show the dice image 6
                

            }
        
            totalDiceScore += myWhiteDice + myBlackDice
            // save the total value of random numbers
            totalScore.text = String(totalDiceScore)
            //convert double to string and show that on the label
            diceOneNumber.text = String(myWhiteDice)
            //convert double to string and show that on the label

            
            diceTwoNumber.text = String(myBlackDice)
            //convert double to string and show that on the label

            myRoundNumber += 1
            // let round number add 1 for every time click the button
            roundNumber.text = String(myRoundNumber)
            //convert double to string and show that on the label

            
            if myRoundNumber >= 25 {
                
                
                playButton.isHidden = true
                // when round number is greater than or equals 25 hide the play button
                restButton.isHidden = false
                   // when round number is greater than or equals 25 show the rest button
               

                 present(alert,animated: true)
                // show the alert box when round number is greater than or equals 25
                
              
            }else {
                playButton.isHidden = false
                // else show the play button
                restButton.isHidden = true
                // else hide the rest button
                
                
            }
        
            
            }
        
  
        
            
            
        countScoreOne()
        // excute the function
       

        
        
        
    }
    
 




    @IBAction func restNow(_ sender: Any) {
        
        
        secondDiceScore = 0
        // rest the value to zero
        diceScore = 0
        // rest the value to zero

        myRoundNumber = 0
        // rest the value to zero

        totalDiceScore = 0
        // rest the value to zero

        totalScore.text = String(zeroValue)
        // show the value of zero on the label
        diceOneNumber.text = String(zeroValue)
        // show the value of zero on the label
        diceTwoNumber.text = String(zeroValue)
        // show the value of zero on the label
        roundNumber.text = String(myRoundNumber)
        // show the value of zero on the label
        playButton.isHidden = false
        // show play button again
        restButton.isHidden = true
        // hide rest button again
       
        
        
 
        
        
        
        
    }
    




}

