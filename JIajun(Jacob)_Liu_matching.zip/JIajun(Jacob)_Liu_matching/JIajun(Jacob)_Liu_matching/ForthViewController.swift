import UIKit




class ForthViewController: UIViewController {

    var duoArray:[Int] = [1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8]
    // create an array
    var countNumber:Int = 1
    // create a number for count and set initial value of 1
    var playerOneScore:Int = 0
    // create a Int to store playerscore
    var playerTwoScore:Int = 0
    // create a Int to store playerscore
    var playerOneRound = true
    // player one turn
    var playerTwoRound = false
    // player two turn
    var cardIsMatched = false
    // card is not matched
    var playerOnePower:Int = 1
    // set growth power of 1 initially
    var playerTwoPower:Int = 1
    // set growth power of 1 initially
    
    var receivedUserOne:String = ""
    // user 1 name
    var receivedUserTwo:String = ""
    // user 2 name
    @IBOutlet weak var playerOneLabel: UILabel!
    @IBOutlet weak var playerTwoLabel: UILabel!
    
    @IBOutlet weak var playerOneScoreLabel: UILabel!
    @IBOutlet weak var playerTwoScoreLabel: UILabel!
    
    @IBOutlet weak var buttonz: UIButton!
    
    @IBOutlet weak var duoButton1: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton2: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton3: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton4: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton5: UIButton!
    
    // create outlet for button
    @IBOutlet weak var duoButton6: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton7: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton8: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton9: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton10: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton11: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton12: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton13: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton14: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton15: UIButton!
    // create outlet for button
    @IBOutlet weak var duoButton16: UIButton!
    // create outlet for button
    
    override func viewDidLoad() {
        super.viewDidLoad()
        playerOneLabel.text = receivedUserOne
        // show player name
        playerTwoLabel.text = receivedUserTwo
        // show player name
        duoArray.shuffle()
        // shuffle
        print(receivedUserOne)
        print(receivedUserTwo)
        print(duoArray)
        countNumber = 1
        // set number to 1
    }
    
    
    func flipCard (cardFliped:UIButton , cardNumber:Int)->UIButton{
        let numOfCard = duoArray[cardNumber]
        // choose image of card
        cardFliped.setImage(UIImage(named: String(numOfCard)), for: .normal)
        // set image for card
        cardFliped.tag = 1
        // set tag to 1
        cardFliped.isUserInteractionEnabled = false
        // disable the button
        cardFliped.alpha = 1
         // set color
        countNumber += 1
         // add 1 each time clicked
        return cardFliped
        // return the value for compare
    }
    
    func duoAnimation (animatedButton:UIButton) {
        UIView.transition(with: animatedButton, duration: 1, options: .transitionFlipFromLeft, animations: nil, completion: nil)
         // show animattion
    }
    
    func findCard(buttonClick:Int) ->UIButton{
        var duoButtonCollection:[UIButton] = [duoButton1,duoButton2,duoButton3,duoButton4,duoButton5,duoButton6,duoButton7,duoButton8,duoButton9,duoButton10,duoButton11,duoButton12,duoButton13,duoButton14,duoButton15,duoButton16]
         // create a button collection
        duoButtonCollection.remove(at: buttonClick)
          // remove the button just clicked from collection
        for (nameOfButoon) in duoButtonCollection{
            if nameOfButoon.tag == 1{
                   // if tag equals 1
                return nameOfButoon
                           // return button
            }
        }
        return buttonz
        // return nothing
    }
    
    func cardsComparation(buttonOne:UIButton , buttonTwo:UIButton){
        if buttonOne.currentImage == buttonTwo.currentImage{
            if playerOneRound == true{
                playerOneScore += 2
                //if cards match add 2 scores
                playerOneScoreLabel.text = String(playerOneScore)
                // show on the label
                playerOnePower += 1
                // add one power
                cardIsMatched = true
                // set isMatched true
                playerOneRound = true
                // set isMatched true
            }else{
                playerTwoScore += 2
                            //if cards match add 2 scores
                playerTwoScoreLabel.text = String(playerTwoScore)
                playerTwoPower += 1
                // add one power
                cardIsMatched = true
                // set isMatched true
                playerOneRound = false
                // set isMatched true
            }
            buttonOne.tag = 3
            // set tag to 3
            buttonTwo.tag = 3
            // set tag to 3
            buttonOne.isUserInteractionEnabled = false
            // disable button
            buttonTwo.isUserInteractionEnabled = false
            // disable button
            buttonOne.alpha = 1
            //change color
            buttonTwo.alpha = 1
            //change color
        }else{
            buttonTwo.tag = 0
            // set tag back to 0
            buttonOne.tag = 0
            // set tag back to 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                // delay code for 0.5 sec
                buttonOne.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.duoAnimation(animatedButton: buttonOne)
                // show animation
                buttonTwo.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.duoAnimation(animatedButton: buttonTwo)
                // show animation
                buttonOne.isUserInteractionEnabled = true
                // enable button
                buttonTwo.isUserInteractionEnabled = true
                // enable button
            }
            if playerOneRound == true{
                playerOneRound = false
                // set matched false
                playerOnePower = 1
                // change power back to 1
            }else{
                playerOneRound = true
                // set matched false
                playerTwoPower = 1
                // change power back to 1
            }
            cardIsMatched = false
        }
    }
    

    
    
    
    func cardMatchedOnce (buttonOne:UIButton , buttonTwo:UIButton){
        if buttonOne.currentImage == buttonTwo.currentImage {
            
            if playerOneRound == true {
                playerOneScore += Int(pow(2, Double(playerOnePower)))
                // add expontial score
                playerOneScoreLabel.text = String(playerOneScore)
                // show score
                playerOnePower += 1
                // add 1 to power
            }else{
                playerTwoScore += Int(pow(2, Double(playerTwoPower)))
                 // add expontial score
                playerTwoScoreLabel.text = String(playerTwoScore)
                 // show score
            }
            buttonOne.tag = 3
            // set tag to 3
            buttonTwo.tag = 3
            // set tag to 3
            buttonOne.isUserInteractionEnabled = false
            // disable the button
            buttonTwo.isUserInteractionEnabled = false
            // disable the button
            buttonOne.alpha = 1
            // change color
            buttonTwo.alpha = 1
            // change color
            cardIsMatched = true
            // set isMatched true
        }else{
            
            if playerOneRound == true{
                playerOneRound = false
                // not player one turn
                playerOnePower = 1
                // set power back to 1
            }else{
                playerOneRound = true
                // playe one turn
                playerTwoPower = 1
                // set power back to 1
            }
            
            buttonOne.tag = 0
                   // set tag back to
            buttonTwo.tag = 0
                   // set tag back to
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                buttonOne.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.duoAnimation(animatedButton: buttonOne)
                  // show animation
                buttonTwo.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.duoAnimation(animatedButton: buttonTwo)
                  // show animation
                buttonOne.isUserInteractionEnabled = true
                 // enable the button
                buttonTwo.isUserInteractionEnabled = true
                 // enable the button
            }
            cardIsMatched = false
            // change back to false
        }
    }
    
    
    func revealAll(revealButton:UIButton , image:Int , interval:Double){
        revealButton.setImage(UIImage(named: "\(image)"), for: .normal)
        // set image
        revealButton.isUserInteractionEnabled = false
        // disable the button
        revealButton.alpha = 1
        // change color
        UIView.transition(with: revealButton, duration: interval, options: .transitionFlipFromLeft, animations: nil, completion: nil)
        // show animation
    }
    
    
    

    
    
    @IBAction func duoButton1Pressed(_ sender: Any) {

        let cardNumberOne = flipCard(cardFliped: duoButton1, cardNumber: 0)
        duoAnimation(animatedButton: duoButton1)
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 0)
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    
    @IBAction func duoButton2Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton2, cardNumber: 1)
        // get return value
        duoAnimation(animatedButton: duoButton2)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 1)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    
    @IBAction func duoButton3Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton3, cardNumber: 2)
        // get return value
        duoAnimation(animatedButton: duoButton3)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 2)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    
    @IBAction func duoButton4Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton4, cardNumber: 3)
        // get return value
        duoAnimation(animatedButton: duoButton4)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 3)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    
    @IBAction func duoButton5Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton5, cardNumber: 4)
        // get return value
        duoAnimation(animatedButton: duoButton5)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 4)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton6Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton6, cardNumber: 5)
        // get return value
        duoAnimation(animatedButton: duoButton6)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 5)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton7Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton7, cardNumber: 6)
        // get return value
        duoAnimation(animatedButton: duoButton7)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 6)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton8Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton8, cardNumber: 7)
        // get return value
        duoAnimation(animatedButton: duoButton8)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 7)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton9Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton9, cardNumber: 8)
        // get return value
        duoAnimation(animatedButton: duoButton9)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 8)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton10Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton10, cardNumber: 9)
        // get return value
        duoAnimation(animatedButton: duoButton10)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 9)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton11Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton11, cardNumber: 10)
        // get return value
        duoAnimation(animatedButton: duoButton11)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 10)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton12Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton12, cardNumber: 11)
        // get return value
        duoAnimation(animatedButton: duoButton12)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 11)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton13Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton13, cardNumber: 12)
        // get return value
        duoAnimation(animatedButton: duoButton13)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 12)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton14Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton14, cardNumber: 13)
        // get return value
        duoAnimation(animatedButton: duoButton14)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 13)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton15Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton15, cardNumber: 14)
        // get return value
        duoAnimation(animatedButton: duoButton15)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 14)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }
    @IBAction func duoButton16Pressed(_ sender: Any) {
        let cardNumberOne = flipCard(cardFliped: duoButton16, cardNumber: 15)
        // get return value
        duoAnimation(animatedButton: duoButton16)
        // show animation
        if countNumber % 2 != 0{
            let cardNumberTwo = findCard(buttonClick: 15)
            // get return value
            if cardIsMatched{
                cardsComparation(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }else{
                cardMatchedOnce(buttonOne: cardNumberOne, buttonTwo: cardNumberTwo)
                 // compare cards
            }
        }
    }

    
    
    @IBAction func revealAllPressed(_ sender: Any) {
        revealAll(revealButton: duoButton1, image: cardNumberArray[0], interval: 0.1)
        // set image back
        revealAll(revealButton: duoButton2, image: cardNumberArray[1], interval: 0.2)
        // set image back
        revealAll(revealButton: duoButton3, image: cardNumberArray[2], interval: 0.3)
        // set image back
        revealAll(revealButton: duoButton4, image: cardNumberArray[3], interval: 0.4)
        // set image back
        revealAll(revealButton: duoButton5, image: cardNumberArray[4], interval: 0.5)
        // set image back
        revealAll(revealButton: duoButton6, image: cardNumberArray[5], interval: 0.6)
        // set image back
        revealAll(revealButton: duoButton7, image: cardNumberArray[6], interval: 0.7)
        // set image back
        revealAll(revealButton: duoButton8, image: cardNumberArray[7], interval: 0.8)
        // set image back
        revealAll(revealButton: duoButton9, image: cardNumberArray[8], interval: 0.9)
        // set image back
        revealAll(revealButton: duoButton10, image: cardNumberArray[9], interval: 1.0)
        // set image back
        revealAll(revealButton: duoButton11, image: cardNumberArray[10], interval: 1.1)
        // set image back
        revealAll(revealButton: duoButton12, image: cardNumberArray[11], interval: 1.2)
        // set image back
        revealAll(revealButton: duoButton13, image: cardNumberArray[12], interval: 1.3)
        // set image back
        revealAll(revealButton: duoButton14, image: cardNumberArray[13], interval: 1.4)
        // set image back
        revealAll(revealButton: duoButton15, image: cardNumberArray[14], interval: 1.5)
        // set image back
        revealAll(revealButton: duoButton16, image: cardNumberArray[15], interval: 1.6)
        // set image back
        
        
    }
    
    
    @IBAction func newGameNew(_ sender: Any) {
         countNumber = 1
        // create a number for count and set initial value of 1
         playerOneScore = 0
        // create a Int to store playerscore
         playerTwoScore = 0
        // create a Int to store playerscore
         playerOneRound = true
        // player one turn
         playerTwoRound = false
        // player two turn
         cardIsMatched = false
        // card is not matched
         playerOnePower = 1
        // set growth power of 1 initially
         playerTwoPower = 1
        // set growth power of 1 initially
        duoArray.shuffle()
        //shuffle
        let xyz:[UIButton] = [duoButton1,duoButton2,duoButton3,duoButton4,duoButton5,duoButton6,duoButton7,duoButton8,duoButton9,duoButton10,duoButton11,duoButton12,duoButton13,duoButton14,duoButton15,duoButton16]
        for (resetButton) in xyz{
            resetButton.tag = 0
            resetButton.setImage(UIImage(named: "9"), for: .normal)
            duoAnimation(animatedButton: resetButton)
        }
        
        
    }
    
    
    
    
    
    
    
}
