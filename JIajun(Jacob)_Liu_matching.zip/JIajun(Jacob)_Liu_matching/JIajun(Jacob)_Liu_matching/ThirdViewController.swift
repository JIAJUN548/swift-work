import UIKit

var timeModeArray:[Int] = [1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8]
// create an array
var timeModeCountNum:Int = 1
// create a number for count and set initial value of 1
var timeModePlayerScore:Int = 0
// player score 0
var isMatchedTimeMode = false
// set ismatched false
var timeModePower:Int = 1
// set growth power of 1 initially
var myTimer = Timer()
// create a timer
var myTime:Int = 0
// set time 0 sec
var matchedTimes:Int = 0
// set matched times 0
var giveUpCardNum:Int = -1
// give up number 1
var myInterval:Double = 0.1
// set interval 0.1
class ThirdViewController: UIViewController {

    var userNameTime:String = ""
    // receive user name for leaderboard

    
    @IBOutlet weak var timeButton1: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton2: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton3: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton4: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton5: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton6: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton7: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton8: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton9: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton10: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton11: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton12: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton13: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton14: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton15: UIButton!
    // create outlet for button
    @IBOutlet weak var timeButton16: UIButton!
    // create outlet for button
    
    
    @IBOutlet weak var resetTime: UIButton!
    // create outlet for button
    @IBOutlet weak var startTimer: UIButton!
    // create outlet for button
    @IBOutlet weak var buttony: UIButton!
    // create outlet for button
    
    @IBOutlet weak var playerScoreTimeMode: UILabel!
    // create outlet for label
    @IBOutlet weak var timeLabel: UILabel!
    // create outlet for label
    override func viewDidLoad() {
        timeModeCountNum = 1
        //set countnumber back to 1
        super.viewDidLoad()
        timeModeArray.shuffle()
        // shuffle array
        timeModePlayerScore = 0
        // set score back to 0
        print(timeModeArray)
        timeModePower = 1
        // set power to 1
        matchedTimes = 0
        // set matched times 0
        myTimer.invalidate()
        // disable timer
        startTimer.isUserInteractionEnabled = true
        // enable button
        giveUpCardNum = -1
        // set number -1
        var myInterval:Double = 0.1

    }
    
    func timeFunc(){
        myTime -= 1
        // minus 1 everytime
        if myTime >= 0{
            timeLabel.text = String(myTime)
            // show time on label
            if matchedTimes == 8{
                myTimer.invalidate()
                // disable timer
            }
        }else{
            myTimer.invalidate()
            // disable timer
            timeLabel.text = "0"
            // set text to 0
        }
    }
    
    func disableTimer () {
        myTimer.invalidate()
        // disable timer
        timeLabel.text = String(0)
        // set text to 0
    }
    
    func timeModeScoreFunc(currentButton:Int)->Int{
        var myButtonCollection:[UIButton] = [timeButton1,timeButton2,timeButton3,timeButton4,timeButton5,timeButton6,timeButton7,timeButton8,timeButton9,timeButton10,timeButton11,timeButton12,timeButton13,timeButton14,timeButton15,timeButton16]
        // create button collection
        myButtonCollection.remove(at: currentButton)
        for (checkedButton) in myButtonCollection {
            // use loop to change image back
            if checkedButton.currentImage == UIImage(named: "9"){
                return 0
                // get 0
            }
        }
        return 1
        // get 1
    }
    
    
    func revealCardTime (cardClickedBefore:UIButton , cardNum:Int) ->UIButton{
        let timeCardNum = timeModeArray[cardNum]
        // get return value
        cardClickedBefore.setImage(UIImage(named: String(timeCardNum)), for: .normal)
        // set image
        cardClickedBefore.tag = 1
        // set tag
        cardClickedBefore.isUserInteractionEnabled = false
        // disable button
        cardClickedBefore.alpha = 1
        // change color
        timeModeCountNum += 1
        // count number + 1
        return cardClickedBefore
        // return the button
    }
    
    func timeModeAnimation (firstButton:UIButton){
        UIView.transition(with: firstButton, duration: 1, options: .transitionFlipFromRight, animations: nil, completion: nil)
        // show animation
    }
    
    func findCardClickedTime (currentButtonPosition:Int) ->UIButton{
        var timeButtonCollection:[UIButton] = [timeButton1,timeButton2,timeButton3,timeButton4,timeButton5,timeButton6,timeButton7,timeButton8,timeButton9,timeButton10,timeButton11,timeButton12,timeButton13,timeButton14,timeButton15,timeButton16]
        // button collection
        timeButtonCollection.remove(at: currentButtonPosition)
        // remove the button just clicked
        for (buttonFound) in timeButtonCollection{
            if buttonFound.tag == 1{
                return buttonFound
                // return the button of tag 1
            }
        }
        
        return buttony
        // nothing
    }
    
    func compareCardFunc (buttonFirst:UIButton , buttonSecond:UIButton){
        
        if buttonFirst.currentImage == buttonSecond.currentImage{
            timeModePlayerScore += 2
            // add 2 score
            playerScoreTimeMode.text = String(timeModePlayerScore)
            //  show score
            buttonFirst.tag = 3
            // set tag to 3
            buttonSecond.tag = 3
            // set tag to 3
            buttonFirst.isUserInteractionEnabled = false
            //disable button
            buttonSecond.isUserInteractionEnabled = false
            //disable button
            buttonFirst.alpha = 1
            // change color
            buttonSecond.alpha = 1
            // change color
            isMatchedTimeMode = true
            // ste it true
            timeModePower += 1
            // add 1 to power
            matchedTimes += 1
            // add 1
        }else{
            buttonFirst.tag = 0
            // set tag 0
            buttonSecond.tag = 0
            // set tag 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                buttonFirst.setImage(UIImage(named: "9"), for: .normal)
                // set image back to 0
                self.timeModeAnimation(firstButton: buttonFirst)
                // show animation
                buttonSecond.setImage(UIImage(named: "9"), for: .normal)
                // set image back to 0
                self.timeModeAnimation(firstButton: buttonSecond)
                // show animation
                buttonFirst.isUserInteractionEnabled = true
                // enable button
                buttonSecond.isUserInteractionEnabled = true
                // enable button
            }
            isMatchedTimeMode = false
            // set it false
            timeModePower = 1
            // set power 1
            
        }
        
        
    }
    
    func timeModeRevealAll(buttonRevealed:UIButton , imageSet:Int , timeInterval:Double){
        
        buttonRevealed.setImage(UIImage(named: "\(imageSet)"), for: .normal)
        // set image
        buttonRevealed.isUserInteractionEnabled = false
        //set it false
        buttonRevealed.alpha = 1
        // change color
        UIView.transition(with: buttonRevealed, duration: timeInterval, options: .transitionFlipFromLeft, animations: nil, completion: nil)
        // show animation
    }
    
    func cardMatchedBefore (oneButton:UIButton , twoButton:UIButton){
        
        if oneButton.currentImage == twoButton.currentImage{
            timeModePlayerScore += Int(pow(2, Double(timeModePower)))
            // add expontial score
            playerScoreTimeMode.text = String(timeModePlayerScore)
            // show score
            oneButton.tag = 3
            // set tag to 3
            twoButton.tag = 3
            // set tag to 3
            oneButton.isUserInteractionEnabled = false
            // disable the button
            twoButton.isUserInteractionEnabled = false
            // disable the button
            oneButton.alpha = 1
            // change color
            twoButton.alpha = 1
            // change color
            isMatchedTimeMode = true
            // set isMatched true
            timeModePower += 1
            // add 1 to power
            matchedTimes += 1
        }else{
            oneButton.tag = 0
            // set tag back to
            twoButton.tag = 0
            // set tag back to
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                oneButton.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                twoButton.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.timeModeAnimation(firstButton: oneButton)
                // show animation
                self.timeModeAnimation(firstButton: twoButton)
                // show animation
                oneButton.isUserInteractionEnabled = true
                // enable the button
                twoButton.isUserInteractionEnabled = true
                // enable the button
            }
            isMatchedTimeMode = false
            // change back to false
            timeModePower = 1
            // set power back to 1
        }
        
    }
    
    func setNewGame(){
        myTime = 120
        // add 120 secs
        timeLabel.text = String(myTime)
        let newGame:[UIButton] = [timeButton1,timeButton2,timeButton3,timeButton4,timeButton5,timeButton6,timeButton7,timeButton8,timeButton9,timeButton10,timeButton11,timeButton12,timeButton13,timeButton14,timeButton15,timeButton16]
        // create a button array
        for (newButton) in newGame{
            newButton.setImage(UIImage(named: "9"), for: .normal)
            timeModeAnimation(firstButton: newButton)
          //  newButton.isUserInteractionEnabled = true
        }
    }
    
    
    @IBAction func timerButtonPressed(_ sender: Any) {
        myTime = 120
        // set 120 sec
        myTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true, block: {_ in self.timeFunc()})
        // enable timer
        startTimer.isUserInteractionEnabled = false
        // disable that
        startTimer.alpha = 1
        // change color
        let buttonsCollection:[UIButton] = [timeButton1,timeButton2,timeButton3,timeButton4,timeButton5,timeButton6,timeButton7,timeButton8,timeButton9,timeButton10,timeButton11,timeButton12,timeButton13,timeButton14,timeButton15,timeButton16]
        // button collection
        for (buttonNeedReset) in buttonsCollection{
            buttonNeedReset.isUserInteractionEnabled = true
        }
    }
    
    
    @IBAction func button1Pressed(_ sender: Any) {
        if myTime > 0 {
            
            let checkNumber = timeModeScoreFunc(currentButton: 0)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            
            let cardOne = revealCardTime(cardClickedBefore: timeButton1, cardNum: 0)
            // get return value
            timeModeAnimation(firstButton: timeButton1)
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 0)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    
    @IBAction func button2Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 1)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton2, cardNum: 1)
            // get return value
            timeModeAnimation(firstButton: timeButton2)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 1)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    @IBAction func button3Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 2)
            
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton3, cardNum: 2)
            timeModeAnimation(firstButton: timeButton3)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 2)
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button4Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 3)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton4, cardNum: 3)
            timeModeAnimation(firstButton: timeButton4)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 3)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button5Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 4)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton5, cardNum: 4)
            // get return value
            timeModeAnimation(firstButton: timeButton5)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 4)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button6Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 5)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton6, cardNum: 5)
            // get return value
            timeModeAnimation(firstButton: timeButton6)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 5)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    @IBAction func button7Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 6)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton7, cardNum: 6)
            // get return value
            timeModeAnimation(firstButton: timeButton7)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 6)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button8Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 7)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton8, cardNum: 7)
            // get return value
            timeModeAnimation(firstButton: timeButton8)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 7)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button9Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 8)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton9, cardNum: 8)
            // get return value
            timeModeAnimation(firstButton: timeButton9)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 8)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button10Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 9)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton10, cardNum: 9)
            // get return value
            timeModeAnimation(firstButton: timeButton10)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 9)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    @IBAction func button11Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 10)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton11, cardNum: 10)
            // get return value
            timeModeAnimation(firstButton: timeButton11)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 10)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    @IBAction func button12Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 11)
            // get return value
            
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton12, cardNum: 11)
            // get return value
            timeModeAnimation(firstButton: timeButton12)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 11)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button13Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 12)
// get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton13, cardNum: 12)
            // get return value
            timeModeAnimation(firstButton: timeButton13)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 12)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button14Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 13)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton14, cardNum: 13)
            // get return value
            timeModeAnimation(firstButton: timeButton14)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 13)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button15Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 14)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton15, cardNum: 14)
            // get return value
            timeModeAnimation(firstButton: timeButton15)
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 14)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func button16Pressed(_ sender: Any) {
        if myTime > 0 {
            let checkNumber = timeModeScoreFunc(currentButton: 15)
            // get return value
            if checkNumber == 1{
                timeModePlayerScore += myTime
                playerScoreTimeMode.text = String(timeModePlayerScore)
            }
            let cardOne = revealCardTime(cardClickedBefore: timeButton16, cardNum: 15)
            // get return value
            timeModeAnimation(firstButton: timeButton16)
            
            // show animation
            if timeModeCountNum % 2 != 0{
                let cardTwo = findCardClickedTime(currentButtonPosition: 15)
                // get return value
                if isMatchedTimeMode == false {
                    compareCardFunc(buttonFirst: cardOne, buttonSecond: cardTwo)
                    // compare cards
                }else{
                    cardMatchedBefore(oneButton: cardOne, twoButton: cardTwo)
                    // compare cards
                }
            }
        }else{
            disableTimer()
        }
    }
    
    @IBAction func revealAllPressed(_ sender: Any) {
        let giveUpCollection:[UIButton] = [timeButton1,timeButton2,timeButton3,timeButton4,timeButton5,timeButton6,timeButton7,timeButton8,timeButton9,timeButton10,timeButton11,timeButton12,timeButton13,timeButton14,timeButton15,timeButton16]
        
        // button collection
        for (giveUpButton) in giveUpCollection{
            giveUpCardNum += 1
            // gve up num add 1
            myInterval += 0.1
            // intervaladd one
            timeModeRevealAll(buttonRevealed: giveUpButton, imageSet: timeModeArray[giveUpCardNum], timeInterval: myInterval)
            // set image
        }
        buttony.isUserInteractionEnabled = false
        // diaable button
        buttony.alpha = 1
        // change color
        myTimer.invalidate()
        // disable timer
    }
    
    @IBAction func newGameIsPressed(_ sender: Any) {
        timeModeCountNum = 1
        // set number back to 1
        timeModeArray.shuffle()
        // shuffle
        buttony.isUserInteractionEnabled = true
        // enable button
        setNewGame()
        // new game
        giveUpCardNum = -1
        // give up  number back to -1
        myInterval = 0.1
        //interval back to 1
        startTimer.isUserInteractionEnabled = true
        // enable button
        timeModePlayerScore = 0
        // score back to 0
        playerScoreTimeMode.text = String(timeModePlayerScore)
        // set text
    }
    
    
    
    
    
    
    
    
}
