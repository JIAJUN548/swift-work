//
//  ViewController.swift
//  JIajun(Jacob)_Liu_matching
//
//  Created by Period Two on 2018-11-21.
//  Copyright © 2018 Period Two. All rights reserved.
//

import UIKit



class ViewController: UIViewController {
    
    var userOne:String = ""
    var userTwo:String = ""
    var practiceUser:String = ""
    var timeUser:String = ""
    var gameMode: Int = 0
    var random:Int = 0
    
    @IBOutlet weak var playerName: UITextField!
    @IBOutlet weak var rulesButton: UIButton!
    @IBOutlet weak var leaderBoard: UIButton!
    @IBOutlet weak var timeButton: UIButton!
    @IBOutlet weak var practiceButton: UIButton!
    @IBOutlet weak var playerNameTwo: UITextField!
    @IBOutlet weak var playerNameOne: UITextField!
    @IBOutlet weak var duoButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
    }
    
    
    @IBAction func practiceModePressed(_ sender: Any) {
        practiceUser = playerName.text!
        gameMode = 1
        performSegue(withIdentifier: "game1", sender: practiceButton)
    }
    
    @IBAction func timeModePressed(_ sender: Any) {
        timeUser = playerName.text!
        gameMode = 2
        performSegue(withIdentifier: "game2", sender: timeButton)
        
    }
    
    
    @IBAction func duoModePressed(_ sender: Any) {
        gameMode = 3
        userOne = playerNameOne.text!
        userTwo = playerNameTwo.text!
        performSegue(withIdentifier: "game3", sender: duoButton)
        
    }
    
    @IBAction func leaderBoardPressed(_ sender: Any) {
        gameMode = 4
        performSegue(withIdentifier: "leaderBoardSeg", sender: leaderBoard)
        
    }
    
    @IBAction func rulesPressed(_ sender: Any) {
        gameMode = 5
        performSegue(withIdentifier: "rules", sender: rulesButton)
    }
    
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if gameMode == 1 {
            let playNamesPractice = segue.destination as! SecondViewController
            playNamesPractice.playerName = practiceUser
        } else if gameMode == 2 {
            let playNamesTime = segue.destination as! ThirdViewController
            playNamesTime.userNameTime = timeUser
        } else if gameMode == 3 {
            let playerNames = segue.destination as! ForthViewController
            playerNames.receivedUserOne = userOne
            playerNames.receivedUserTwo = userTwo
        }else if gameMode == 4{
            random = 4
        }else if gameMode == 5 {
            random = 5
        }
        
        
       
        
        
    }
 
    
    
    

}

