import UIKit

var cardNumberArray:[Int] = [1,2,3,4,5,6,7,8,1,2,3,4,5,6,7,8]
// create an array
var numberForCount:Int = 1
// create a number for count and set initial value of 1
var playerScore:Int = 0
// create a Int to store playerscore
var isMatched = false
// set card matched is false
var power:Int = 1
// set growth power of 1 initially
var leaderBoard = [String:Int]()
// create a fictionary for leaderboard
var leaderScore:Int = 0
// create a variable to receive data for leaderboard

class SecondViewController: UIViewController {
    

    var playerName:String = ""
    // create a variable to receive data for leaderboard
    var nameData = UserDefaults.standard
    // for save data
    var scoreData = UserDefaults.standard
    // for save date

    
    @IBOutlet weak var button1: UIButton!
    // create outlet for button
    @IBOutlet weak var button2: UIButton!
    // create outlet for button
    @IBOutlet weak var button3: UIButton!
    // create outlet for button
    @IBOutlet weak var button4: UIButton!
    // create outlet for button
    @IBOutlet weak var button5: UIButton!
    // create outlet for button
    @IBOutlet weak var button6: UIButton!
    // create outlet for button
    @IBOutlet weak var button7: UIButton!
    // create outlet for button
    @IBOutlet weak var button8: UIButton!
    // create outlet for button
    @IBOutlet weak var button9: UIButton!
    // create outlet for button
    @IBOutlet weak var button10: UIButton!
    // create outlet for button
    @IBOutlet weak var button11: UIButton!
    // create outlet for button
    @IBOutlet weak var button12: UIButton!
    // create outlet for button
    @IBOutlet weak var button13: UIButton!
    // create outlet for button
    @IBOutlet weak var button14: UIButton!
    // create outlet for button
    @IBOutlet weak var button15: UIButton!
    // create outlet for button
    @IBOutlet weak var button16: UIButton!
    // create outlet for button

    
    @IBOutlet weak var buttonx: UIButton!
    // create outlet for button

    
    @IBOutlet weak var playerScoreLabel: UILabel!
    // create outlet for label

    @IBOutlet weak var triedTimesLabel: UILabel!
    // create outlet for label

    override func viewDidLoad() {
        super.viewDidLoad()
        numberForCount = 1
        //set countnumber back to 1
        cardNumberArray.shuffle()
        //shuffle array
        playerScore = 0
        // set score back to 0
        print(cardNumberArray)
        power = 1
        // set power back to 0
    }
    
    func revealCard (cardClicked:UIButton , numberOfCard:Int) ->UIButton {
        let cardNumber = cardNumberArray[numberOfCard]
        // choose image of card
        cardClicked.setImage(UIImage(named: String(cardNumber)), for: .normal)
        // set image for card
        cardClicked.tag = 1
        // set tag to 1
        cardClicked.isUserInteractionEnabled = false
        // disable the button
        cardClicked.alpha = 1
        // set color
        numberForCount += 1
        // add 1 each time clicked
        triedTimesLabel.text = String(numberForCount - 1)
        // show tried times
        return cardClicked
        // return the value for compare
    }
    
    func animationFunc (buttonOne:UIButton) {
        UIView.transition(with: buttonOne, duration: 1, options: .transitionFlipFromLeft, animations: nil, completion: nil)
        // show animattion
    }
    
    

    func findCardClicked (currentButton:Int) -> UIButton{
        var buttonCollection:[UIButton] = [button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,
                                           button12,button13,button14,button15,button16]
        // create a button collection
        buttonCollection.remove(at: currentButton)
        // remove the button just clicked from collection
        for (buttonName) in buttonCollection {
            if buttonName.tag == 1 {
                // if tag equals 1
                return buttonName
                // return button
            }
        }
        return buttonx
        // return nothing
    }
    
    func compareCard (firstButton:UIButton , secondButton:UIButton) {
        
        if firstButton.currentImage == secondButton.currentImage {
            playerScore += 2
            //if cards match add 2 scores
            playerScoreLabel.text = String((playerScore))
            // show on the label
            firstButton.tag = 3
            // set tag to 3
            secondButton.tag = 3
            // set tag to 3
            firstButton.isUserInteractionEnabled = false
            // disable button
            secondButton.isUserInteractionEnabled = false
            // disable  button
            firstButton.alpha = 1
            //change color
            secondButton.alpha = 1
            //change color
            isMatched = true
            // set isMatched true
            power += 1
            // add one power
        }else{
            firstButton.tag = 0
            // set tag back to 0
            secondButton.tag = 0
            // set tag back to 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                // delay code for 0.5 sec
                firstButton.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.animationFunc(buttonOne: firstButton)
                // show animation
                secondButton.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.animationFunc(buttonOne: secondButton)
                // show animation
                firstButton.isUserInteractionEnabled = true
                // enable button
                secondButton.isUserInteractionEnabled = true
                // enable button
            }
         
         
            isMatched = false
            // set matched false
            power = 1
            // change power back to 1
            
        }
        
    }
    
    func revealAll(revealButton:UIButton , image:Int , interval:Double){
        revealButton.setImage(UIImage(named: "\(image)"), for: .normal)
        // set image
        revealButton.isUserInteractionEnabled = false
        // disable the button
        revealButton.alpha = 1
        // change color
        UIView.transition(with: revealButton, duration: interval, options: .transitionFlipFromLeft, animations: nil, completion: nil)
        // show animation
    }
    
    func matchedBefore (buttonOne:UIButton , buttonTwo:UIButton){

        if buttonOne.currentImage == buttonTwo.currentImage{
            playerScore += Int(pow(2, Double(power)))
            // add expontial score
            playerScoreLabel.text = String(playerScore)
            // show score
            buttonOne.tag = 3
            // set tag to 3
            buttonTwo.tag = 3
            // set tag to 3
            buttonOne.isUserInteractionEnabled = false
            // disable the button
            buttonTwo.isUserInteractionEnabled = false
            // disable the button
            buttonOne.alpha = 1
            // change color
            buttonTwo.alpha = 1
            // change color
            isMatched = true
            // set isMatched true
            power += 1
            // add 1 to power
        }else{
            buttonOne.tag = 0
            // set tag back to
            buttonTwo.tag = 0
            // set tag back to 0
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                buttonOne.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                buttonTwo.setImage(UIImage(named: "9"), for: .normal)
                // set back image
                self.animationFunc(buttonOne: buttonTwo)
                // show animation
                self.animationFunc(buttonOne: buttonOne)
                // show animation
                buttonOne.isUserInteractionEnabled = true
                // enable the button
                buttonTwo.isUserInteractionEnabled = true
                // enable the button
            }
            
            isMatched = false
            // change back to false
            power = 1
            // set power back to 1
        }

    }
    
    func newGameFunc (){
        let newGameArray:[UIButton] = [button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,
                                       button12,button13,button14,button15,button16]
        // create a button array
        for (newButton) in newGameArray {
            newButton.setImage(UIImage(named: "9"), for: .normal)
            // set same image
            animationFunc(buttonOne: newButton)
            // show animation
        }
    }
    
    // compare cards
    // get return value
    
    @IBAction func praPicOnePressed(_ sender: Any) {
        
        let cardNumOne = revealCard(cardClicked: button1, numberOfCard: 0)
        // get return value
        animationFunc(buttonOne: button1)
        // show animation
        if numberForCount % 2 != 0{
            let cardNumberTwo = findCardClicked(currentButton: 0)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards
            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards
            }
            
        }
        
        
        
        
    }
    
    @IBAction func buttonTwoPressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button2, numberOfCard: 1)
        // get return value
        animationFunc(buttonOne: button2)
        // show animation
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 1)
            // get return value

            if isMatched == false{
            compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
   
        
        
        
        
    }
    
    
    @IBAction func buttonThreePressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button3, numberOfCard: 2)
        // get return value
        animationFunc(buttonOne: button3)
        // show animation
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 2)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
    
        
    }
    
    
    
    
    @IBAction func buttonFourPressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button4, numberOfCard: 3)
        // get return value
        animationFunc(buttonOne: button4)
        // show animation
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 3)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
      
      
    }
    
    @IBAction func buttonFivePressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button5, numberOfCard: 4)
        // get return value
        animationFunc(buttonOne: button5)
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 4)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
    



    }
    
    @IBAction func buttonSixPressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button6, numberOfCard: 5)
        // get return value
        animationFunc(buttonOne: button6)
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 5)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
      
        
    }
    
    @IBAction func buttonSevenPressed(_ sender: Any) {
        let cardNumOne = revealCard(cardClicked: button7, numberOfCard: 6)
        // get return value
        animationFunc(buttonOne: button7)
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 6)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
  
        
    }
    
    @IBAction func buttonEightPressed(_ sender: Any) {
        animationFunc(buttonOne: button8)
        let cardNumOne = revealCard(cardClicked: button8, numberOfCard: 7)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 7)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }




    }
    
    
    @IBAction func buttonNinePressed(_ sender: Any) {
        animationFunc(buttonOne: button9)
        let cardNumOne = revealCard(cardClicked: button9, numberOfCard: 8)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 8)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
    
        
        
    }
    
    @IBAction func buttonTenPressed(_ sender: Any) {
        animationFunc(buttonOne: button10)
        let cardNumOne = revealCard(cardClicked: button10, numberOfCard: 9)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 9)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
   
        
    }
    
    @IBAction func buttonElevenPressed(_ sender: Any) {
        animationFunc(buttonOne: button11)
        let cardNumOne = revealCard(cardClicked: button11, numberOfCard: 10)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 10)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
  
        
    }
    
    @IBAction func buttonTwelvePressed(_ sender: Any) {
        animationFunc(buttonOne: button12)
        let cardNumOne = revealCard(cardClicked: button12, numberOfCard: 11)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 11)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
      
        
        
    }
    
    
    @IBAction func buttonThirteenPressed(_ sender: Any) {
        animationFunc(buttonOne: button13)
        let cardNumOne = revealCard(cardClicked: button13, numberOfCard: 12)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 12)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
      
    }
    
    @IBAction func buttonFourteenPressed(_ sender: Any) {
        animationFunc(buttonOne: button14)
        let cardNumOne = revealCard(cardClicked: button14, numberOfCard: 13)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 13)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
     
        
    }
    
    
    @IBAction func buttonFifteenPressed(_ sender: Any) {
        animationFunc(buttonOne: button15)
        let cardNumOne = revealCard(cardClicked: button15, numberOfCard: 14)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 14)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
     
        
    }
    
    @IBAction func buttonSixteenPressed(_ sender: Any) {
        animationFunc(buttonOne: button16)
        let cardNumOne = revealCard(cardClicked: button16, numberOfCard: 15)
        // get return value
        if numberForCount % 2 != 0 {
            let cardNumberTwo = findCardClicked(currentButton: 15)
            // get return value
            if isMatched == false{
                compareCard(firstButton: cardNumOne, secondButton: cardNumberTwo)
                // compare cards

            }else{
                matchedBefore(buttonOne: cardNumOne, buttonTwo: cardNumberTwo)
                // compare cards

            }
        }
        
        
    }
    
    
    @IBAction func giveUpButtonPressed(_ sender: Any) {

        revealAll(revealButton: button1, image: cardNumberArray[0], interval: 0.1)
        // set image back
        revealAll(revealButton: button2, image: cardNumberArray[1], interval: 0.2)
        // set image back
        revealAll(revealButton: button3, image: cardNumberArray[2], interval: 0.3)
        // set image back
        revealAll(revealButton: button4, image: cardNumberArray[3], interval: 0.4)
        // set image back
        revealAll(revealButton: button5, image: cardNumberArray[4], interval: 0.5)
        // set image back
        revealAll(revealButton: button6, image: cardNumberArray[5], interval: 0.6)
        // set image back
        revealAll(revealButton: button7, image: cardNumberArray[6], interval: 0.7)
        // set image back
        revealAll(revealButton: button8, image: cardNumberArray[7], interval: 0.8)
        // set image back
        revealAll(revealButton: button9, image: cardNumberArray[8], interval: 0.9)
        // set image back
        revealAll(revealButton: button10, image: cardNumberArray[9], interval: 1.0)
        // set image back
        revealAll(revealButton: button11, image: cardNumberArray[10], interval: 1.1)
        // set image back
        revealAll(revealButton: button12, image: cardNumberArray[11], interval: 1.2)
        // set image back
        revealAll(revealButton: button13, image: cardNumberArray[12], interval: 1.3)
        // set image back
        revealAll(revealButton: button14, image: cardNumberArray[13], interval: 1.4)
        // set image back
        revealAll(revealButton: button15, image: cardNumberArray[14], interval: 1.5)
        // set image back
        revealAll(revealButton: button16, image: cardNumberArray[15], interval: 1.6)
        // set image back
        
    }
    
    
    @IBAction func newGamePressed(_ sender: Any) {
        
        let buttonRest:[UIButton] = [button1,button2,button3,button4,button5,button6,button7,button8,button9,button10,button11,
                                     button12,button13,button14,button15,button16]
        // create button collection
        for (needRest) in buttonRest{
            needRest.tag = 0
            // set tag to 0
        }
        
        cardNumberArray.shuffle()
        // shuffle array
        newGameFunc()
        // new game
        print(cardNumberArray)
        numberForCount = 1
        // set count number back to 1
        nameData.set(playerName, forKey: "practiceUser")
        // save data
        scoreData.set(playerScore, forKey: "practiceScore")
        // save data
        
        if let pracScore:Int = UserDefaults.standard.value(forKey: "practiceScore") as? Int{
            
            leaderDictionary[pracScore] = String(0)
            leaderScore = pracScore
      //      leaderDictionary[pracName] = 0
      //      leaderName = pracName
        }
        if let pracName:String = UserDefaults.standard.value(forKey: "practiceUser") as? String{
           leaderDictionary[leaderScore] = pracName
       //     leaderDictionary[leaderName] = pracScore
        }
        
        
    }
    
    
    
    
}
