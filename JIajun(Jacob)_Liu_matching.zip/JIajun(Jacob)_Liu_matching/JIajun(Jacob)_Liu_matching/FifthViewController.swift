

import UIKit

var leaderDictionary:[Int: String] = [:]

class FifthViewController: UIViewController , UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let myCell = UITableViewCell()
        myCell.textLabel?.text = String(0.1)
        return myCell
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        leaderDictionary.sorted{ $0.1 < $1.1}
        print(leaderDictionary)
    }

}
// get return value
// compare cards
// show animation
